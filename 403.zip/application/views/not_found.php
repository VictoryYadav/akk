<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Page Not Found</title>
</head>
<body>
	<img src="<?= base_url()?>assets/images/not_found.jpg" style="width: 100%;height: 100vh;">
</body>
</html>