<?php
	/**
	 * 
	 */
	class Common_model extends CI_Model
	{