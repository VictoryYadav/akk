<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Home extends CI_Controller {

	public function __construct()
	{
		parent::__construct();


		$this->load->library('grocery_CRUD');
	}
	function check_login(){
		if(!empty($_COOKIE['user_id'])){
			return $_COOKIE['user_id'];
		}else{
			redirect(base_url().'login');
		}
	}
	/**

	 * Index Page for this controller.

	 *

	 * Maps to the following URL

	 * 		http://example.com/index.php/welcome

	 *	- or -

	 * 		http://example.com/index.php/welcome/index

	 *	- or -

	 * Since this controller is set as the default controller in

	 * config/routes.php, it's displayed at http://example.com/

	 *

	 * So any other public methods not prefixed with an underscore will

	 * map to /index.php/welcome/<method_name>

	 * @see https://codeigniter.com/user_guide/general/urls.html

	 */

	function register(){
		if($_POST){
			$this->load->library('form_validation');
			$this->form_validation->set_rules('name', 'Name', 'required', array(
                'required'      => 'You have not provided %s.'
        		));
			$this->form_validation->set_rules('email', 'Email', 'required|is_unique[users.email]', array(
                'required'      => 'You have not provided %s.',
                'is_unique'     => 'This %s already exists.'
        		));
			if($this->form_validation->run()){
				$data['name'] = $_POST['name'];
				$data['email'] = $_POST['email'];
				$data['password'] = md5($_POST['password']);
				$this->db->insert('users', $data);
				redirect(base_url().'home/login');
			}
		}
		$this->load->view('register');
	}
	function login(){
		if($_POST){
			$email = $_POST['email'];
			$password = md5($_POST['password']);
			
			$check = $this->db->where('email', $email)->where('password', $password)->get('users')->row_array();
			if(!empty($check)){
				set_cookie('user_id', $check['id'], 3600*24*365);
				set_cookie('name', $check['name'], 3600*24*365);
				redirect(base_url().'home/general_info');
			}else{
				$_SESSION['login_error'] = 1;
			}
		}
		$this->load->view('login');
	}
	function logout(){
		delete_cookie('user_id');
		delete_cookie('email');
		redirect(base_url().'home/login');
	}
	public function index()

	{

		$this->load->view('index');
		// $this->_example_output((object)array('output' => '' , 'js_files' => array() , 'css_files' => array()));

	}

	function not_found(){

		$this->load->view('not_found');

	}



	function heat_data(){

		$data = $this->db->query("SELECT d.Domain,sd.SubDomain, chd.SDCd, chd.HML as hrHML, ced.HML as CEOHML FROM comphrdet chd, compceodet ced, domain d, domainsub sd WHERE chd.CCNo=ced.CCNo and ced.CCNo=1 and chd.SDCd=ced.SDCd and sd.SDCd=chd.SDCd and d.DCd=sd.DCd ORDER by sd.DCd, sd.SDCd")->result_array();

		$heat_data = array();

		$catg = array();

		$domain = $this->db->get('domain')->result_array();

		$tool = array();

		$n = 0;

		foreach($domain as $d){

			$data = $this->db->query("SELECT d.Domain,sd.SubDomain, chd.SDCd, chd.HML as hrHML, ced.HML as CEOHML FROM comphrdet chd, compceodet ced, domain d, domainsub sd WHERE chd.CCNo=ced.CCNo and ced.CCNo=1 and chd.SDCd=ced.SDCd and sd.SDCd=chd.SDCd and d.DCd=sd.DCd and d.DCd=".$d['DCd']." ORDER by sd.DCd, sd.SDCd")->result_array();

			$i=1;

			$arr = array();

			$arr['name'] = $d['Domain'];

			$arr['data'] = array();

			foreach($data as $key){

				if($key['CEOHML'] == 1 && $key['hrHML'] == 1){

					array_push($arr['data'], array('x' => "", 'y' => 1));

				}elseif($key['CEOHML'] == 1 && $key['hrHML'] == 2){

					array_push($arr['data'], array('x' => "", 'y' => 2));

				}elseif($key['CEOHML'] == 1 && $key['hrHML'] == 3){

					array_push($arr['data'], array('x' => "", 'y' => 3));

				}elseif($key['CEOHML'] == 2 && $key['hrHML'] == 1){

					array_push($arr['data'], array('x' => "", 'y' => 4));

				}elseif($key['CEOHML'] == 2 && $key['hrHML'] == 2){

					array_push($arr['data'], array('x' => "", 'y' => 5));

				}elseif($key['CEOHML'] == 2 && $key['hrHML'] == 3){

					array_push($arr['data'], array('x' => "", 'y' => 6));

				}elseif($key['CEOHML'] == 3 && $key['hrHML'] == 1){

					array_push($arr['data'], array('x' => "", 'y' => 7));

				}elseif($key['CEOHML'] == 3 && $key['hrHML'] == 2){

					array_push($arr['data'], array('x' => "", 'y' => 8));

				}elseif($key['CEOHML'] == 3 && $key['hrHML'] == 3){

					array_push($arr['data'], array('x' => "", 'y' => 9));

				}

				$tool[$n][$i-1] = $key['SubDomain'];//." - ".intval($key['CEOHML']);

				$i++;

			}

			$n++;

			

			array_push($heat_data, $arr);



		}

		$res = array('data' => json_encode($heat_data), 'tool' => json_encode($tool));

		// echo "<pre>";print_r(($res));

		$this->load->view('index2', $res);

	}
	public function _example_output($output = null)
	{
		$this->load->view('grocery_crud.php',(array)$output);
	}

	public function offices()
	{
		$output = $this->grocery_crud->render();

		$this->_example_output($output);
	}

	

	public function manage_companies()
	{
		$this->check_login();
		try{
			$crud = new grocery_CRUD();

			$crud->set_theme('datatables');
			$crud->set_table('company');
			$crud->set_subject('Company');
			$crud->required_fields('Name');
			// $crud->columns('city','country','phone','addressLine1','postalCode');

			$output = $crud->render();

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}
	public function general_info()
	{
		$this->check_login();
		$crud = new grocery_CRUD();

		$crud->set_theme('datatables');
		$crud->set_table('general_info');
		$crud->unset_columns('created_at', 'updated_at');
		$crud->set_relation('company_id','company','Name');
		// $crud->display_as('officeCode','Office City');
		// $crud->required_fields('lastName');
		$crud->set_subject('General Info');

		// $crud->required_fields('lastName');

		// $crud->set_field_upload('file_url','assets/uploads/files');

		$output = $crud->render();

		$this->_example_output($output);
	}
	public function training_details()
	{
		$this->check_login();
		$crud = new grocery_CRUD();

		$crud->set_theme('datatables');
		$crud->set_table('training_related_details');
		$crud->unset_columns('created_at', 'updated_at');
		$crud->set_relation('company_id','company','CompCd');
		// $crud->display_as('officeCode','Office City');
		$crud->set_subject('Training Details');

		// $crud->required_fields('lastName');

		// $crud->set_field_upload('file_url','assets/uploads/files');

		$output = $crud->render();

		$this->_example_output($output);
	}



}

